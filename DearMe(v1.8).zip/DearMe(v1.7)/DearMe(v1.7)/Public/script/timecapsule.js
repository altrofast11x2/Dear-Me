/* ============================================
   Dear Me - 타임캡슐 관리 시스템 (다중 파일 업로드)
   ============================================ */

(function () {
    'use strict';

    // DOM 요소 캐싱
    const elements = {
        form: document.getElementById('capsuleForm'),
        listContainer: document.getElementById('capsuleList'),
        searchInput: document.getElementById('search'),
        filterSelect: document.getElementById('filter'),
        exportBtn: document.getElementById('exportBtn'),
        mediaInput: document.getElementById('mediaUpload'),
        fileLabel: document.getElementById('selectedFiles'),

        // 폼 입력 필드
        titleInput: document.getElementById('title'),
        contentInput: document.getElementById('content'),
        openAtInput: document.getElementById('openAt'),
        visibilitySelect: document.getElementById('visibility'),
        passwordInput: document.getElementById('password')
    };

    // 상태 관리
    let capsules = [];
    let currentFilter = 'all';
    let searchQuery = '';
    let selectedFiles = []; // 선택된 파일들

    /* ============================================
       초기화
       ============================================ */
    function init() {
        loadCapsules();
        renderCapsules();
        attachEventListeners();
        setMinDateTime();
        checkStorageUsage();
        renderNavigationHeader();
    }

    /* ============================================
       헤더 렌더링
       ============================================ */
    function renderNavigationHeader() {
        const header = document.querySelector('.page-header');
        if (!header) return;

        const nav = document.createElement('nav');
        nav.className = 'page-nav';
        nav.style.cssText = `
            display: flex;
            gap: 12px;
            margin-top: 16px;
            padding-top: 16px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        `;

        nav.innerHTML = `
            <button class="nav-link" style="padding: 8px 16px; border-radius: 8px; background: var(--accent-soft); color: var(--accent-primary); border: none; cursor: pointer; font-weight: 500; font-size: 15px; transition: all 0.2s ease;">
                ← 돌아가기
            </button>
        `;

        const backBtn = nav.querySelector('.nav-link');
        backBtn.addEventListener('click', () => {
            window.location.href = './community.html';
        });

        backBtn.addEventListener('mouseenter', () => {
            backBtn.style.background = 'var(--accent-primary)';
            backBtn.style.color = 'white';
        });

        backBtn.addEventListener('mouseleave', () => {
            backBtn.style.background = 'var(--accent-soft)';
            backBtn.style.color = 'var(--accent-primary)';
        });

        header.appendChild(nav);
    }

    /* ============================================
       이벤트 리스너 등록
       ============================================ */
    function attachEventListeners() {
        elements.form.addEventListener('submit', handleFormSubmit);
        elements.searchInput.addEventListener('input', uiUtils.debounce(handleSearch, 300));
        elements.filterSelect.addEventListener('change', handleFilterChange);
        elements.exportBtn.addEventListener('click', handleExport);
        elements.mediaInput.addEventListener('change', handleFileSelect);
        elements.visibilitySelect.addEventListener('change', togglePasswordField);

        // 드래그 앤 드롭 이벤트
        const dropZone = document.getElementById('dropZone');
        if (dropZone) {
            // 드래그 오버 효과
            ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
                dropZone.addEventListener(eventName, preventDefaults, false);
            });

            ['dragenter', 'dragover'].forEach(eventName => {
                dropZone.addEventListener(eventName, () => {
                    dropZone.classList.add('drag-over');
                }, false);
            });

            ['dragleave', 'drop'].forEach(eventName => {
                dropZone.addEventListener(eventName, () => {
                    dropZone.classList.remove('drag-over');
                }, false);
            });

            // 파일 드롭 처리
            dropZone.addEventListener('drop', handleDrop, false);

            // 클릭으로도 파일 선택 가능
            dropZone.addEventListener('click', (e) => {
                if (e.target === dropZone || e.target.closest('.drop-zone-content')) {
                    elements.mediaInput.click();
                }
            });
        }

        // 폼 리셋 시 파일 목록도 초기화
        elements.form.addEventListener('reset', () => {
            selectedFiles = [];
            elements.fileLabel.innerHTML = '';
        });
    }

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    function handleDrop(e) {
        const dt = e.dataTransfer;
        const files = Array.from(dt.files);

        if (files.length === 0) return;

        // 최대 5개 파일 제한
        if (selectedFiles.length + files.length > 5) {
            uiUtils.showNotification('최대 5개의 파일만 업로드할 수 있습니다.', 'warning');
            return;
        }

        // 각 파일 검증
        for (const file of files) {
            if (file.size > 100 * 1024 * 1024) {
                uiUtils.showNotification(`${file.name}의 크기가 100MB를 초과합니다.`, 'error');
                return;
            }
        }

        // 파일 추가
        selectedFiles.push(...files);
        renderFileList();
        uiUtils.showNotification(`${files.length}개의 파일이 추가되었습니다.`, 'success');
    }

    /* ============================================
       파일 처리
       ============================================ */
    function getFileIcon(fileType) {
        if (fileType.startsWith('image/')) return '🖼️';
        if (fileType.startsWith('video/')) return '🎥';
        if (fileType.includes('pdf')) return '📄';
        if (fileType.includes('word') || fileType.includes('document')) return '📝';
        if (fileType.includes('sheet') || fileType.includes('excel')) return '📊';
        if (fileType.includes('text')) return '📃';
        return '📎';
    }

    function handleFileSelect(event) {
        const files = Array.from(event.target.files || []);

        if (files.length === 0) return;

        // 최대 5개 파일 제한
        if (selectedFiles.length + files.length > 5) {
            uiUtils.showNotification('최대 5개의 파일만 업로드할 수 있습니다.', 'warning');
            elements.mediaInput.value = '';
            return;
        }

        // 각 파일 검증
        for (const file of files) {
            if (file.size > 100 * 1024 * 1024) {
                uiUtils.showNotification(`${file.name}의 크기가 100MB를 초과합니다.`, 'error');
                elements.mediaInput.value = '';
                return;
            }
        }

        // 파일 추가
        selectedFiles.push(...files);
        renderFileList();
        elements.mediaInput.value = ''; // input 초기화
    }

    function removeFile(index) {
        if (index >= 0 && index < selectedFiles.length) {
            selectedFiles.splice(index, 1);
            renderFileList();
        }
    }

    function renderFileList() {
        if (!elements.fileLabel) return;

        if (selectedFiles.length === 0) {
            elements.fileLabel.innerHTML = '';
            return;
        }

        // 파일 개수 표시
        const countBadge = `
            <div class="files-count">
                📎 ${selectedFiles.length}개의 파일 선택됨
            </div>
        `;

        const fileItems = selectedFiles.map((file, index) => {
            const icon = getFileIcon(file.type);
            const size = fileUtils.formatSize(file.size);
            const name = securityUtils.escapeHTML(file.name);

            return `
                <div class="file-item">
                    <div class="file-item-info">
                        <div class="file-item-icon">${icon}</div>
                        <div class="file-item-details">
                            <div class="file-item-name" title="${name}">${name}</div>
                            <div class="file-item-meta">
                                <span class="file-item-size">${size}</span>
                            </div>
                        </div>
                    </div>
                    <button type="button" class="file-item-remove" data-index="${index}">
                        🗑️ 삭제
                    </button>
                </div>
            `;
        }).join('');

        elements.fileLabel.innerHTML = countBadge + fileItems;

        // 삭제 버튼에 이벤트 리스너 추가
        elements.fileLabel.querySelectorAll('.file-item-remove').forEach(btn => {
            btn.addEventListener('click', function () {
                const index = parseInt(this.getAttribute('data-index'));
                removeFile(index);
            });
        });
    }

    /* ============================================
       데이터 관리
       ============================================ */
    function loadCapsules() {
        capsules = storageUtils.load();
        capsules = capsules.filter(capsule => {
            return capsule.id && capsule.title !== undefined && capsule.openAt &&
                !isNaN(new Date(capsule.openAt).getTime());
        });
    }

    function saveCapsules() {
        const success = storageUtils.save(capsules);
        if (success) {
            renderCapsules();
            checkStorageUsage();
        } else {
            uiUtils.showNotification('저장에 실패했습니다. 저장 공간을 확인해주세요.', 'error');
        }
    }

    async function addCapsule(capsuleData) {
        const sanitized = {
            id: securityUtils.generateSecureId(),
            title: securityUtils.sanitizeInput(capsuleData.title, 200),
            content: securityUtils.sanitizeInput(capsuleData.content, 10000),
            openAt: capsuleData.openAt,
            visibility: capsuleData.visibility,
            password: capsuleData.password ? capsuleData.password : '',
            media: capsuleData.media || [], // 배열로 저장
            createdAt: new Date().toISOString(),
            opened: false,
            openedAt: null,
            sharedToCommunity: false
        };

        if (!sanitized.title.trim()) {
            uiUtils.showNotification('제목을 입력해주세요.', 'warning');
            return false;
        }

        if (!sanitized.openAt || dateUtils.isPast(sanitized.openAt)) {
            uiUtils.showNotification('개봉 날짜는 미래여야 합니다.', 'warning');
            return false;
        }

        capsules.unshift(sanitized);
        saveCapsules();

        // 공개 설정이면 자동으로 커뮤니티에 공유
        if (sanitized.visibility === 'public') {
            autoShareToCommunity(sanitized);
        } else {
            uiUtils.showNotification('타임캡슐이 저장되었습니다!', 'success');
        }

        return true;
    }

    function deleteCapsule(id) {
        const capsule = capsules.find(c => c.id === id);
        if (!capsule) return;

        if (capsule.password) {
            const inputPassword = prompt('캡슐 비밀번호를 입력하세요:');
            if (inputPassword === null) return;
            if (inputPassword !== capsule.password) {
                uiUtils.showNotification('비밀번호가 일치하지 않습니다.', 'error');
                return;
            }
        }

        const confirmMessage = `"${capsule.title}" 캡슐을 삭제하시겠습니까?\n이 작업은 되돌릴 수 없습니다.`;
        if (!confirm(confirmMessage)) return;

        capsules = capsules.filter(c => c.id !== id);
        saveCapsules();
        uiUtils.showNotification('캡슐이 삭제되었습니다.', 'info');
    }

    function updateCapsule(id, updates) {
        const index = capsules.findIndex(c => c.id === id);
        if (index === -1) return;
        capsules[index] = { ...capsules[index], ...updates };
        saveCapsules();
    }

    /* ============================================
       커뮤니티 자동 공유
       ============================================ */
    function autoShareToCommunity(capsule) {
        if (!window.authSystem || !window.authSystem.isLoggedIn()) {
            uiUtils.showNotification('커뮤니티 공유는 로그인이 필요합니다. 타임캡슐은 저장되었습니다.', 'warning');
            return;
        }

        if (window.createCommunityPost) {
            // 미디어 데이터 복사 (참조가 아닌 새 배열)
            const mediaCopy = capsule.media ? JSON.parse(JSON.stringify(capsule.media)) : [];

            const success = window.createCommunityPost({
                title: capsule.title,
                content: capsule.content,
                openAt: capsule.openAt,
                password: capsule.password,
                media: mediaCopy,
                visibility: capsule.visibility,
                originalCapsuleId: capsule.id
            });

            if (success) {
                updateCapsule(capsule.id, { sharedToCommunity: true });
                uiUtils.showNotification('타임캡슐이 저장되고 커뮤니티에 공유되었습니다!', 'success');

                // 3초 후 커뮤니티로 이동
                setTimeout(() => {
                    window.location.href = './community.html';
                }, 2000);
            }
        } else {
            uiUtils.showNotification('타임캡슐이 저장되었습니다!', 'success');
        }
    }

    function resetCapsuleShareStatus(capsuleId) {
        const index = capsules.findIndex(c => c.id === capsuleId);
        if (index !== -1) {
            capsules[index].sharedToCommunity = false;
            saveCapsules();
        }
    }

    /* ============================================
       렌더링
       ============================================ */
    function renderCapsules() {
        const filtered = getFilteredCapsules();
        elements.listContainer.innerHTML = '';

        if (filtered.length === 0) {
            renderEmptyState();
            return;
        }

        filtered.forEach(capsule => {
            const capsuleElement = createCapsuleElement(capsule);
            elements.listContainer.appendChild(capsuleElement);
        });
    }

    function getFilteredCapsules() {
        return capsules.filter(capsule => {
            if (searchQuery) {
                const searchText = `${capsule.title} ${capsule.content}`.toLowerCase();
                if (!searchText.includes(searchQuery.toLowerCase())) return false;
            }

            const isOpen = dateUtils.isPast(capsule.openAt);
            if (currentFilter === 'locked' && isOpen) return false;
            if (currentFilter === 'open' && !isOpen) return false;

            return true;
        });
    }

    function createCapsuleElement(capsule) {
        const isOpen = dateUtils.isPast(capsule.openAt);
        const statusClass = isOpen ? 'open' : 'locked';

        const div = document.createElement('div');
        div.className = `capsule-item ${statusClass}`;

        const infoDiv = document.createElement('div');
        infoDiv.className = 'capsule-info';

        const title = document.createElement('h3');
        title.className = 'capsule-title';
        title.textContent = capsule.title || '(제목 없음)';

        const meta = document.createElement('div');
        meta.className = 'capsule-meta';

        const openDate = document.createElement('span');
        openDate.className = 'capsule-meta-item';
        openDate.textContent = `📅 ${dateUtils.format(capsule.openAt, 'full')}`;

        const relativeTime = document.createElement('span');
        relativeTime.className = 'capsule-meta-item';
        relativeTime.textContent = `⏱️ ${dateUtils.getRelativeTime(capsule.openAt)}`;

        meta.appendChild(openDate);
        meta.appendChild(relativeTime);

        if (capsule.sharedToCommunity) {
            const sharedBadge = document.createElement('span');
            sharedBadge.className = 'capsule-meta-item';
            sharedBadge.textContent = '🌐 커뮤니티 공유됨';
            sharedBadge.style.color = 'var(--accent-primary)';
            meta.appendChild(sharedBadge);
        }

        infoDiv.appendChild(title);
        infoDiv.appendChild(meta);

        const actionsDiv = document.createElement('div');
        actionsDiv.className = 'capsule-actions';

        const openBtn = document.createElement('button');
        openBtn.className = `btn capsule-btn ${isOpen ? 'primary' : 'ghost'}`;
        openBtn.textContent = isOpen ? '열기' : '잠김';
        openBtn.onclick = () => tryOpenCapsule(capsule);

        const deleteBtn = document.createElement('button');
        deleteBtn.className = 'btn danger capsule-btn';
        deleteBtn.textContent = '삭제';
        deleteBtn.onclick = (e) => {
            e.stopPropagation();
            deleteCapsule(capsule.id);
        };

        actionsDiv.appendChild(openBtn);
        actionsDiv.appendChild(deleteBtn);

        div.appendChild(infoDiv);
        div.appendChild(actionsDiv);

        div.onclick = (e) => {
            if (e.target === div || e.target === infoDiv || e.target === title || e.target === meta) {
                tryOpenCapsule(capsule);
            }
        };

        return div;
    }

    function renderEmptyState() {
        const emptyDiv = document.createElement('div');
        emptyDiv.className = 'empty-state';
        emptyDiv.innerHTML = `
      <div class="empty-state-icon">📦</div>
      <div class="empty-state-title">저장된 캡슐이 없습니다</div>
      <div class="empty-state-desc">
        ${searchQuery || currentFilter !== 'all'
                ? '검색 조건에 맞는 캡슐이 없습니다.'
                : '왼쪽 폼에서 첫 타임캡슐을 만들어보세요!'}
      </div>
    `;
        elements.listContainer.appendChild(emptyDiv);
    }

    /* ============================================
       캡슐 열기 로직
       ============================================ */
    function tryOpenCapsule(capsule) {
        if (dateUtils.isFuture(capsule.openAt)) {
            const timeLeft = dateUtils.getRelativeTime(capsule.openAt);
            uiUtils.showNotification(`아직 개봉일이 아닙니다. (${timeLeft})`, 'warning');
            return;
        }

        if (capsule.visibility === 'private' && capsule.password) {
            const inputPassword = prompt('비밀번호를 입력하세요:');
            if (inputPassword === null) return;
            if (inputPassword !== capsule.password) {
                uiUtils.showNotification('비밀번호가 일치하지 않습니다.', 'error');
                return;
            }
        }

        showCapsuleModal(capsule);

        if (!capsule.opened) {
            updateCapsule(capsule.id, {
                opened: true,
                openedAt: new Date().toISOString()
            });
        }
    }

    function showCapsuleModal(capsule) {
        const template = document.getElementById('modalTpl');
        const clone = template.content.cloneNode(true);

        const backdrop = clone.querySelector('.modal-backdrop');
        const modal = backdrop.querySelector('.modal');

        const titleEl = modal.querySelector('h2');
        titleEl.textContent = capsule.title || '(제목 없음)';

        const metaEl = modal.querySelector('#modalMeta');
        metaEl.textContent = `작성일: ${dateUtils.format(capsule.createdAt)} · 개봉일: ${dateUtils.format(capsule.openAt)}`;

        const contentEl = modal.querySelector('#modalContent');
        contentEl.innerHTML = '';

        const contentText = document.createElement('p');
        contentText.textContent = capsule.content || '(내용 없음)';
        contentEl.appendChild(contentText);

        // 다중 미디어 표시
        if (capsule.media && capsule.media.length > 0) {
            const mediaGrid = document.createElement('div');
            mediaGrid.className = 'media-grid';

            capsule.media.forEach(file => {
                const mediaItem = document.createElement('div');
                mediaItem.className = 'media-item';

                if (file.type.startsWith('image')) {
                    const img = document.createElement('img');
                    img.src = file.data;
                    img.alt = file.name;
                    mediaItem.appendChild(img);
                } else if (file.type.startsWith('video')) {
                    const video = document.createElement('video');
                    video.src = file.data;
                    video.controls = true;
                    mediaItem.appendChild(video);
                } else {
                    // 문서 파일
                    const docDiv = document.createElement('div');
                    docDiv.className = 'media-item-doc';
                    docDiv.innerHTML = `
                        <div class="media-item-doc-icon">${getFileIcon(file.type)}</div>
                        <div class="media-item-doc-name">${file.name}</div>
                        <button class="btn ghost" style="margin-top: 8px; padding: 6px 12px; font-size: 12px;" 
                                onclick="downloadFile('${file.data}', '${file.name}')">
                            다운로드
                        </button>
                    `;
                    mediaItem.appendChild(docDiv);
                }

                mediaGrid.appendChild(mediaItem);
            });

            contentEl.appendChild(mediaGrid);
        }

        const closeBtn = modal.querySelector('#closeModal');
        closeBtn.onclick = () => backdrop.remove();

        backdrop.onclick = (e) => {
            if (e.target === backdrop) backdrop.remove();
        };

        const handleEscape = (e) => {
            if (e.key === 'Escape') {
                backdrop.remove();
                document.removeEventListener('keydown', handleEscape);
            }
        };
        document.addEventListener('keydown', handleEscape);

        document.body.appendChild(backdrop);
    }

    /* ============================================
       이벤트 핸들러
       ============================================ */
    async function handleFormSubmit(e) {
        e.preventDefault();

        let mediaDataArray = [];

        // 파일 처리
        if (selectedFiles.length > 0) {
            uiUtils.showNotification('파일을 처리 중입니다...', 'info');

            for (const file of selectedFiles) {
                try {
                    const base64 = await fileUtils.toBase64(file);
                    mediaDataArray.push({
                        name: file.name,
                        type: file.type,
                        size: file.size,
                        data: base64
                    });
                } catch (error) {
                    console.error('파일 처리 오류:', error);
                    uiUtils.showNotification(`${file.name} 처리 중 오류가 발생했습니다.`, 'error');
                    return;
                }
            }
        }

        const password = elements.passwordInput.value.trim();
        if (password) {
            const validation = securityUtils.validatePassword(password);
            if (!validation.isValid) {
                uiUtils.showNotification(validation.message, 'warning');
                return;
            }
        }

        const capsuleData = {
            title: elements.titleInput.value.trim(),
            content: elements.contentInput.value.trim(),
            openAt: elements.openAtInput.value,
            visibility: elements.visibilitySelect.value,
            password: password,
            media: mediaDataArray // 배열로 전달
        };

        const success = await addCapsule(capsuleData);

        if (success) {
            elements.form.reset();
            selectedFiles = [];
            elements.fileLabel.innerHTML = '';
            setMinDateTime();
        }
    }

    function handleSearch(e) {
        searchQuery = e.target.value.trim();
        renderCapsules();
    }

    function handleFilterChange(e) {
        currentFilter = e.target.value;
        renderCapsules();
    }

    function handleExport() {
        if (capsules.length === 0) {
            uiUtils.showNotification('내보낼 캡슐이 없습니다.', 'info');
            return;
        }

        try {
            const data = JSON.stringify(capsules, null, 2);
            const blob = new Blob([data], { type: 'application/json' });
            const url = URL.createObjectURL(blob);

            const link = document.createElement('a');
            link.href = url;
            link.download = `DearMe_Backup_${new Date().toISOString().split('T')[0]}.json`;
            link.click();

            URL.revokeObjectURL(url);
            uiUtils.showNotification('백업 파일이 다운로드되었습니다.', 'success');
        } catch (error) {
            uiUtils.showNotification('내보내기 중 오류가 발생했습니다.', 'error');
        }
    }

    function togglePasswordField() {
        const isPrivate = elements.visibilitySelect.value === 'private';
        elements.passwordInput.disabled = !isPrivate;
        elements.passwordInput.style.opacity = isPrivate ? '1' : '0.5';
    }

    /* ============================================
       유틸리티
       ============================================ */
    function setMinDateTime() {
        const now = new Date();
        now.setMinutes(now.getMinutes() + 1);
        const minDateTime = now.toISOString().slice(0, 16);
        elements.openAtInput.min = minDateTime;

        if (!elements.openAtInput.value) {
            elements.openAtInput.value = minDateTime;
        }
    }

    function checkStorageUsage() {
        const info = storageUtils.getStorageInfo();
        if (info.percentage > 80) {
            uiUtils.showNotification(
                `저장 공간이 ${info.percentage}% 사용되었습니다. 일부 캡슐을 삭제해주세요.`,
                'warning'
            );
        }
    }

    function downloadFile(base64Data, filename) {
        const link = document.createElement('a');
        link.href = base64Data;
        link.download = filename;
        link.click();
    }

    /* ============================================
       전역 함수
       ============================================ */
    window.resetCapsuleShareStatus = resetCapsuleShareStatus;
    window.downloadFile = downloadFile;

    /* ============================================
       앱 시작
       ============================================ */
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();