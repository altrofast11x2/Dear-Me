/* ============================================
   Dear Me - 인증 시스템
   ============================================ */

(function () {
    'use strict';

    const AUTH_KEY = 'dearme_auth_v1';
    const USERS_KEY = 'dearme_users_v1';

    /* ============================================
       사용자 관리
       ============================================ */

    class AuthSystem {
        constructor() {
            this.currentUser = this.loadCurrentUser();
        }

        /**
         * 현재 로그인한 사용자 정보 로드
         */
        loadCurrentUser() {
            try {
                const authData = localStorage.getItem(AUTH_KEY);
                if (!authData) return null;

                const { userId, expiresAt } = JSON.parse(authData);

                // 세션 만료 체크
                if (new Date().getTime() > expiresAt) {
                    this.logout();
                    return null;
                }

                const users = this.getAllUsers();
                return users.find(u => u.id === userId) || null;
            } catch (error) {
                console.error('사용자 로드 실패:', error);
                return null;
            }
        }

        /**
         * 모든 사용자 목록 가져오기
         */
        getAllUsers() {
            try {
                const data = localStorage.getItem(USERS_KEY);
                return data ? JSON.parse(data) : [];
            } catch (error) {
                console.error('사용자 목록 로드 실패:', error);
                return [];
            }
        }

        /**
         * 사용자 목록 저장
         */
        saveUsers(users) {
            try {
                localStorage.setItem(USERS_KEY, JSON.stringify(users));
                return true;
            } catch (error) {
                console.error('사용자 저장 실패:', error);
                return false;
            }
        }

        /**
         * 회원가입
         */
        async register(username, password) {
            // 입력 검증
            if (!username || username.length < 3) {
                return {
                    success: false,
                    message: '닉네임은 3자 이상이어야 합니다.'
                };
            }

            if (!password || password.length < 4) {
                return {
                    success: false,
                    message: '비밀번호는 4자 이상이어야 합니다.'
                };
            }

            // 닉네임 중복 체크
            const users = this.getAllUsers();
            if (users.some(u => u.username === username)) {
                return {
                    success: false,
                    message: '이미 사용 중인 닉네임입니다.'
                };
            }

            // 비밀번호 해시
            const hashedPassword = await this.hashPassword(password);

            // 새 사용자 생성
            const newUser = {
                id: this.generateUserId(),
                username: securityUtils.sanitizeInput(username, 50),
                password: hashedPassword,
                createdAt: new Date().toISOString(),
                avatar: this.generateAvatar(username),
                postCount: 0
            };

            users.push(newUser);
            this.saveUsers(users);

            return {
                success: true,
                message: '회원가입이 완료되었습니다.',
                user: newUser
            };
        }

        /**
         * 로그인
         */
        async login(username, password) {
            const users = this.getAllUsers();
            const user = users.find(u => u.username === username);

            if (!user) {
                return {
                    success: false,
                    message: '존재하지 않는 사용자입니다.'
                };
            }

            // 비밀번호 확인
            const hashedPassword = await this.hashPassword(password);
            if (user.password !== hashedPassword) {
                return {
                    success: false,
                    message: '비밀번호가 일치하지 않습니다.'
                };
            }

            // 세션 생성 (7일)
            const expiresAt = new Date().getTime() + (7 * 24 * 60 * 60 * 1000);
            const authData = {
                userId: user.id,
                expiresAt
            };

            localStorage.setItem(AUTH_KEY, JSON.stringify(authData));
            this.currentUser = user;

            return {
                success: true,
                message: '로그인 되었습니다.',
                user
            };
        }

        /**
         * 로그아웃
         */
        logout() {
            localStorage.removeItem(AUTH_KEY);
            this.currentUser = null;
        }

        /**
         * 로그인 상태 확인
         */
        isLoggedIn() {
            return this.currentUser !== null;
        }

        /**
         * 현재 사용자 정보
         */
        getCurrentUser() {
            return this.currentUser;
        }

        /**
         * 비밀번호 해시 (간단한 SHA-256)
         */
        async hashPassword(password) {
            const encoder = new TextEncoder();
            const data = encoder.encode(password + 'dearme_salt');
            const hashBuffer = await crypto.subtle.digest('SHA-256', data);
            const hashArray = Array.from(new Uint8Array(hashBuffer));
            return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
        }

        /**
         * 사용자 ID 생성
         */
        generateUserId() {
            return 'user_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
        }

        /**
         * 아바타 생성 (이니셜)
         */
        generateAvatar(username) {
            return username.charAt(0).toUpperCase();
        }

        /**
         * 사용자 포스트 수 증가
         */
        incrementPostCount(userId) {
            const users = this.getAllUsers();
            const userIndex = users.findIndex(u => u.id === userId);

            if (userIndex !== -1) {
                users[userIndex].postCount++;
                this.saveUsers(users);

                if (this.currentUser && this.currentUser.id === userId) {
                    this.currentUser.postCount++;
                }
            }
        }
    }

    /* ============================================
       로그인 UI
       ============================================ */

    function showLoginModal() {
        const existingModal = document.querySelector('.auth-modal-backdrop');
        if (existingModal) {
            existingModal.remove();
        }

        const backdrop = document.createElement('div');
        backdrop.className = 'modal-backdrop auth-modal-backdrop';
        backdrop.innerHTML = `
      <div class="modal" style="max-width: 400px;">
        <div class="modal-header">
          <h2 class="modal-title">🔐 로그인</h2>
          <button class="btn ghost" onclick="this.closest('.modal-backdrop').remove()">✕</button>
        </div>
        
        <div style="padding: 20px 0;">
          <div class="form-group">
            <label class="form-label">닉네임</label>
            <input type="text" id="loginUsername" class="form-input" placeholder="닉네임을 입력하세요" autofocus>
          </div>
          
          <div class="form-group">
            <label class="form-label">비밀번호</label>
            <input type="password" id="loginPassword" class="form-input" placeholder="비밀번호를 입력하세요">
          </div>
          
          <button class="btn primary" style="width: 100%; margin-top: 16px;" onclick="handleLogin()">
            로그인
          </button>
          
          <div style="text-align: center; margin-top: 16px; color: var(--text-muted);">
            계정이 없으신가요? 
            <a href="#" onclick="showRegisterModal(); return false;" style="color: var(--accent-primary);">회원가입</a>
          </div>
        </div>
      </div>
    `;

        document.body.appendChild(backdrop);

        // Enter 키로 로그인
        backdrop.querySelectorAll('input').forEach(input => {
            input.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') handleLogin();
            });
        });
    }

    function showRegisterModal() {
        const existingModal = document.querySelector('.auth-modal-backdrop');
        if (existingModal) {
            existingModal.remove();
        }

        const backdrop = document.createElement('div');
        backdrop.className = 'modal-backdrop auth-modal-backdrop';
        backdrop.innerHTML = `
      <div class="modal" style="max-width: 400px;">
        <div class="modal-header">
          <h2 class="modal-title">✨ 회원가입</h2>
          <button class="btn ghost" onclick="this.closest('.modal-backdrop').remove()">✕</button>
        </div>
        
        <div style="padding: 20px 0;">
          <div class="form-group">
            <label class="form-label">닉네임 (3자 이상)</label>
            <input type="text" id="registerUsername" class="form-input" placeholder="닉네임을 입력하세요" autofocus>
          </div>
          
          <div class="form-group">
            <label class="form-label">비밀번호 (4자 이상)</label>
            <input type="password" id="registerPassword" class="form-input" placeholder="비밀번호를 입력하세요">
          </div>
          
          <div class="form-group">
            <label class="form-label">비밀번호 확인</label>
            <input type="password" id="registerPasswordConfirm" class="form-input" placeholder="비밀번호를 다시 입력하세요">
          </div>
          
          <button class="btn primary" style="width: 100%; margin-top: 16px;" onclick="handleRegister()">
            회원가입
          </button>
          
          <div style="text-align: center; margin-top: 16px; color: var(--text-muted);">
            이미 계정이 있으신가요? 
            <a href="#" onclick="showLoginModal(); return false;" style="color: var(--accent-primary);">로그인</a>
          </div>
        </div>
      </div>
    `;

        document.body.appendChild(backdrop);

        // Enter 키로 회원가입
        backdrop.querySelectorAll('input').forEach(input => {
            input.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') handleRegister();
            });
        });
    }

    async function handleLogin() {
        const username = document.getElementById('loginUsername').value.trim();
        const password = document.getElementById('loginPassword').value;

        if (!username || !password) {
            uiUtils.showNotification('모든 필드를 입력해주세요.', 'warning');
            return;
        }

        const result = await window.authSystem.login(username, password);

        if (result.success) {
            uiUtils.showNotification(result.message, 'success');
            document.querySelector('.auth-modal-backdrop').remove();

            // 페이지 새로고침
            setTimeout(() => {
                window.location.reload();
            }, 500);
        } else {
            uiUtils.showNotification(result.message, 'error');
        }
    }

    async function handleRegister() {
        const username = document.getElementById('registerUsername').value.trim();
        const password = document.getElementById('registerPassword').value;
        const passwordConfirm = document.getElementById('registerPasswordConfirm').value;

        if (!username || !password || !passwordConfirm) {
            uiUtils.showNotification('모든 필드를 입력해주세요.', 'warning');
            return;
        }

        if (password !== passwordConfirm) {
            uiUtils.showNotification('비밀번호가 일치하지 않습니다.', 'error');
            return;
        }

        const result = await window.authSystem.register(username, password);

        if (result.success) {
            uiUtils.showNotification(result.message, 'success');
            document.querySelector('.auth-modal-backdrop').remove();

            // 자동 로그인
            setTimeout(async () => {
                await window.authSystem.login(username, password);
                window.location.reload();
            }, 500);
        } else {
            uiUtils.showNotification(result.message, 'error');
        }
    }

    /* ============================================
       전역 초기화
       ============================================ */

    window.authSystem = new AuthSystem();
    window.showLoginModal = showLoginModal;
    window.showRegisterModal = showRegisterModal;
    window.handleLogin = handleLogin;
    window.handleRegister = handleRegister;

})();