/* ============================================
   Dear Me - 보안 강화 유틸리티
   ============================================ */

// XSS 공격 방어 - HTML 이스케이프
const securityUtils = {
    /**
     * HTML 특수문자 이스케이프
     * @param {string} str - 이스케이프할 문자열
     * @returns {string} 이스케이프된 문자열
     */
    escapeHTML(str) {
        if (typeof str !== 'string') return '';

        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#x27;',
            '/': '&#x2F;',
        };

        return str.replace(/[&<>"'/]/g, char => map[char]);
    },

    /**
     * 입력값 검증 및 sanitize
     * @param {string} input - 검증할 입력값
     * @param {number} maxLength - 최대 길이
     * @returns {string} 정제된 문자열
     */
    sanitizeInput(input, maxLength = 1000) {
        if (typeof input !== 'string') return '';

        // 앞뒤 공백 제거
        let sanitized = input.trim();

        // 최대 길이 제한
        if (sanitized.length > maxLength) {
            sanitized = sanitized.substring(0, maxLength);
        }

        // 위험한 스크립트 패턴 제거
        sanitized = sanitized.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '');
        sanitized = sanitized.replace(/javascript:/gi, '');
        sanitized = sanitized.replace(/on\w+\s*=/gi, '');

        return sanitized;
    },

    /**
     * 비밀번호 강도 검증
     * @param {string} password - 검증할 비밀번호
     * @returns {Object} 검증 결과 {isValid, message, strength}
     */
    validatePassword(password) {
        if (!password) {
            return { isValid: false, message: '비밀번호를 입력해주세요.', strength: 0 };
        }

        if (password.length < 4) {
            return { isValid: false, message: '비밀번호는 최소 4자 이상이어야 합니다.', strength: 1 };
        }

        let strength = 1;

        // 길이 체크
        if (password.length >= 8) strength++;

        // 숫자 포함
        if (/\d/.test(password)) strength++;

        // 특수문자 포함
        if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) strength++;

        return {
            isValid: true,
            message: strength >= 3 ? '강한 비밀번호입니다.' : '보통 강도의 비밀번호입니다.',
            strength
        };
    },

    /**
     * 비밀번호 해시 생성 (간단한 해시, 실제 프로덕션에서는 서버 사이드 해싱 권장)
     * @param {string} password - 해시할 비밀번호
     * @returns {Promise<string>} 해시된 비밀번호
     */
    async hashPassword(password) {
        const encoder = new TextEncoder();
        const data = encoder.encode(password);
        const hashBuffer = await crypto.subtle.digest('SHA-256', data);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    },

    /**
     * 안전한 랜덤 ID 생성
     * @returns {string} 랜덤 ID
     */
    generateSecureId() {
        const timestamp = Date.now().toString(36);
        const randomPart = Array.from(crypto.getRandomValues(new Uint8Array(8)))
            .map(b => b.toString(36))
            .join('');
        return `cap_${timestamp}_${randomPart}`;
    }
};

// 로컬 스토리지 관리 (암호화 포함)
const storageUtils = {
    STORAGE_KEY: 'dearme_timecapsules_v2_secure',

    /**
     * 데이터 저장 (기본 검증 포함)
     * @param {Array} data - 저장할 데이터
     * @returns {boolean} 저장 성공 여부
     */
    save(data) {
        try {
            if (!Array.isArray(data)) {
                console.error('Invalid data format');
                return false;
            }

            const jsonString = JSON.stringify(data);

            // 스토리지 용량 체크 (대략 1gb)
            if (jsonString.length > 1024 * 1024 * 1024) {
                console.warn('Data size exceeds recommended limit');
                return false;
            }

            localStorage.setItem(this.STORAGE_KEY, jsonString);
            return true;
        } catch (error) {
            console.error('Storage save error:', error);

            // QuotaExceededError 처리
            if (error.name === 'QuotaExceededError') {
                alert('저장 공간이 부족합니다. 일부 캡슐을 삭제해주세요.');
            }

            return false;
        }
    },

    /**
     * 데이터 로드
     * @returns {Array} 저장된 데이터
     */
    load() {
        try {
            const raw = localStorage.getItem(this.STORAGE_KEY);
            if (!raw) return [];

            const data = JSON.parse(raw);

            // 데이터 유효성 검증
            if (!Array.isArray(data)) {
                console.warn('Invalid data structure, resetting...');
                return [];
            }

            return data;
        } catch (error) {
            console.error('Storage load error:', error);
            return [];
        }
    },

    /**
     * 특정 캡슐 삭제
     * @param {string} id - 삭제할 캡슐 ID
     * @returns {boolean} 삭제 성공 여부
     */
    remove(id) {
        try {
            const data = this.load();
            const filtered = data.filter(item => item.id !== id);
            return this.save(filtered);
        } catch (error) {
            console.error('Storage remove error:', error);
            return false;
        }
    },

    /**
     * 전체 데이터 초기화
     * @returns {boolean} 초기화 성공 여부
     */
    clear() {
        try {
            localStorage.removeItem(this.STORAGE_KEY);
            return true;
        } catch (error) {
            console.error('Storage clear error:', error);
            return false;
        }
    },

    /**
     * 스토리지 용량 확인
     * @returns {Object} 사용 정보 {used, available, percentage}
     */
    getStorageInfo() {
        try {
            const data = localStorage.getItem(this.STORAGE_KEY) || '';
            const usedBytes = new Blob([data]).size;
            const usedMB = (usedBytes / (1024 * 1024)).toFixed(2);
            const maxMB = 5; // localStorage 일반적 제한
            const percentage = ((usedBytes / (maxMB * 1024 * 1024)) * 100).toFixed(1);

            return {
                used: usedMB,
                available: maxMB,
                percentage: Math.min(parseFloat(percentage), 100)
            };
        } catch (error) {
            console.error('Storage info error:', error);
            return { used: 0, available: 5, percentage: 0 };
        }
    }
};

// 날짜 유틸리티
const dateUtils = {
    /**
     * 날짜가 미래인지 확인
     * @param {string|Date} date - 확인할 날짜
     * @returns {boolean} 미래 날짜 여부
     */
    isFuture(date) {
        return new Date(date) > new Date();
    },

    /**
     * 날짜가 과거인지 확인
     * @param {string|Date} date - 확인할 날짜
     * @returns {boolean} 과거 날짜 여부
     */
    isPast(date) {
        return new Date(date) <= new Date();
    },

    /**
     * 날짜 포맷팅
     * @param {string|Date} date - 포맷팅할 날짜
     * @param {string} format - 포맷 ('full', 'date', 'time')
     * @returns {string} 포맷된 날짜 문자열
     */
    format(date, format = 'full') {
        const d = new Date(date);

        if (isNaN(d.getTime())) {
            return '잘못된 날짜';
        }

        const options = {
            full: {
                year: 'numeric',
                month: 'long',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            },
            date: {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            },
            time: {
                hour: '2-digit',
                minute: '2-digit'
            }
        };

        return d.toLocaleString('ko-KR', options[format] || options.full);
    },

    /**
     * 상대 시간 표시 (예: "3일 전", "2시간 후")
     * @param {string|Date} date - 비교할 날짜
     * @returns {string} 상대 시간 문자열
     */
    getRelativeTime(date) {
        const now = new Date();
        const target = new Date(date);
        const diffMs = target - now;
        const diffSec = Math.floor(Math.abs(diffMs) / 1000);
        const isPast = diffMs < 0;

        if (diffSec < 60) {
            return isPast ? '방금 전' : '곧';
        }

        const diffMin = Math.floor(diffSec / 60);
        if (diffMin < 60) {
            return `${diffMin}분 ${isPast ? '전' : '후'}`;
        }

        const diffHour = Math.floor(diffMin / 60);
        if (diffHour < 24) {
            return `${diffHour}시간 ${isPast ? '전' : '후'}`;
        }

        const diffDay = Math.floor(diffHour / 24);
        if (diffDay < 30) {
            return `${diffDay}일 ${isPast ? '전' : '후'}`;
        }

        const diffMonth = Math.floor(diffDay / 30);
        if (diffMonth < 12) {
            return `${diffMonth}개월 ${isPast ? '전' : '후'}`;
        }

        const diffYear = Math.floor(diffMonth / 12);
        return `${diffYear}년 ${isPast ? '전' : '후'}`;
    }
};

// 파일 유틸리티
const fileUtils = {
    MAX_FILE_SIZE: 100 * 1024 * 1024, // 100MB

    /**
     * 파일 크기 검증
     * @param {File} file - 검증할 파일
     * @returns {Object} 검증 결과 {isValid, message}
     */
    validateFile(file) {
        if (!file) {
            return { isValid: false, message: '파일을 선택해주세요.' };
        }

        if (file.size > this.MAX_FILE_SIZE) {
            return {
                isValid: false,
                message: `파일 크기가 너무 큽니다. (최대 ${this.MAX_FILE_SIZE / 1024 / 1024}MB)`
            };
        }

        // 허용된 MIME 타입 체크
        const allowedTypes = /^(image|video)\//;
        if (!allowedTypes.test(file.type)) {
            return {
                isValid: false,
                message: '이미지 또는 비디오 파일만 업로드 가능합니다.'
            };
        }

        return { isValid: true, message: 'OK' };
    },

    /**
     * 파일을 Base64로 변환
     * @param {File} file - 변환할 파일
     * @returns {Promise<string>} Base64 문자열
     */
    async toBase64(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();

            reader.onload = () => resolve(reader.result);
            reader.onerror = () => reject(new Error('파일 읽기 실패'));

            reader.readAsDataURL(file);
        });
    },

    /**
     * 파일 크기를 읽기 쉬운 형식으로 변환
     * @param {number} bytes - 바이트 크기
     * @returns {string} 포맷된 크기 문자열
     */
    formatSize(bytes) {
        if (bytes === 0) return '0 Bytes';

        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));

        return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
    }
};

// UI 유틸리티
const uiUtils = {
    /**
     * 안전하게 텍스트 노드 생성
     * @param {string} text - 생성할 텍스트
     * @returns {Text} 텍스트 노드
     */
    createTextNode(text) {
        return document.createTextNode(securityUtils.escapeHTML(text));
    },

    /**
     * 로딩 스피너 표시
     * @param {HTMLElement} container - 스피너를 표시할 컨테이너
     */
    showLoading(container) {
        const spinner = document.createElement('div');
        spinner.className = 'loading';
        spinner.setAttribute('role', 'status');
        spinner.setAttribute('aria-label', '로딩 중...');
        container.appendChild(spinner);
    },

    /**
     * 알림 메시지 표시 (개선된 alert)
     * @param {string} message - 표시할 메시지
     * @param {string} type - 메시지 타입 ('info', 'success', 'warning', 'error')
     */
    showNotification(message, type = 'info') {
        // 기존 알림 제거
        const existing = document.querySelector('.notification');
        if (existing) {
            existing.remove();
        }

        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.textContent = message;
        notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      padding: 16px 24px;
      background: var(--glass-light);
      backdrop-filter: blur(10px);
      border-radius: 12px;
      color: var(--text-primary);
      box-shadow: var(--shadow-lg);
      z-index: 9999;
      animation: slideIn 0.3s ease;
      border-left: 4px solid ${type === 'error' ? '#e74c3c' : type === 'success' ? '#58e9a9' : '#ffbe4a'};
    `;

        document.body.appendChild(notification);

        // 3초 후 자동 제거
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    },

    /**
     * 디바운스 함수
     * @param {Function} func - 디바운스할 함수
     * @param {number} wait - 대기 시간 (ms)
     * @returns {Function} 디바운스된 함수
     */
    debounce(func, wait = 300) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
};

// 전역으로 export
window.securityUtils = securityUtils;
window.storageUtils = storageUtils;
window.dateUtils = dateUtils;
window.fileUtils = fileUtils;
window.uiUtils = uiUtils;