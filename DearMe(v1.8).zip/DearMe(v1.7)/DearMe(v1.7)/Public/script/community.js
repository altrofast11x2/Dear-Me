/* ============================================
   Dear Me - 커뮤니티 시스템 (최적화 버전)
============================================= */

(function () {
  'use strict';

  const POSTS_KEY = 'dearme_community_posts_v1';
  let posts = [];
  let currentFilter = 'recent';

  const els = {
    postsList: document.getElementById('postsList'),
    filterTabs: document.querySelectorAll('.filter-tab'),
    postTrigger: document.getElementById('postTrigger'),
    userInfo: document.getElementById('userInfo')
  };

  /* ============================================
   공통 헬퍼
  ============================================= */
  const $el = (tag, props = {}, children = []) => {
    const el = document.createElement(tag);
    Object.assign(el, props);
    if (props.style) Object.assign(el.style, props.style);
    children.forEach(child => el.appendChild(child));
    return el;
  };

  const safeJSON = (str, fallback = []) => {
    try { return JSON.parse(str); } catch { return fallback; }
  };

  const getFileIcon = type =>
    type.startsWith('image/') ? '🖼️' :
    type.startsWith('video/') ? '🎥' :
    type.includes('pdf')      ? '📄' :
    type.includes('word')     ? '📝' :
    type.includes('sheet')    ? '📊' :
    type.includes('text')     ? '📃' : '📎';

  /* ============================================
   Posts Manager
  ============================================= */
  const postsManager = {
    load() {
      posts = safeJSON(localStorage.getItem(POSTS_KEY), []);
      posts = posts.filter(p => p.id && p.authorId && p.title);
    },

    save() {
      try {
        localStorage.setItem(POSTS_KEY, JSON.stringify(posts));
        return true;
      } catch (e) {
        console.error('포스트 저장 실패:', e);
        return false;
      }
    },

    create(postData) {
      const user = window.authSystem.getCurrentUser();
      if (!user) return uiUtils.showNotification('로그인이 필요합니다.', 'warning');

      const newPost = {
        id: securityUtils.generateSecureId(),
        authorId: user.id,
        authorName: user.username,
        authorAvatar: user.avatar,
        title: securityUtils.sanitizeInput(postData.title, 200),
        content: securityUtils.sanitizeInput(postData.content, 10000),
        openAt: postData.openAt,
        password: postData.password || '',
        media: safeJSON(JSON.stringify(postData.media || []), []),
        visibility: postData.visibility || 'public',
        createdAt: new Date().toISOString(),
        likes: 0,
        comments: 0,
        originalCapsuleId: postData.originalCapsuleId || null
      };

      posts.unshift(newPost);

      if (!this.save()) {
        uiUtils.showNotification('게시물 저장에 실패했습니다.', 'error');
        return false;
      }

      window.authSystem.incrementPostCount(user.id);
      uiManager.refresh();
      uiUtils.showNotification('타임캡슐이 공유되었습니다!', 'success');
      return true;
    },

    delete(id) {
      const post = posts.find(p => p.id === id);
      if (!post) return;

      const user = window.authSystem.getCurrentUser();
      if (!user || user.id !== post.authorId)
        return uiUtils.showNotification('본인 게시물만 삭제할 수 있습니다.', 'error');

      if (post.password && prompt('비밀번호를 입력하세요:') !== post.password)
        return uiUtils.showNotification('비밀번호가 일치하지 않습니다.', 'error');

      if (!confirm(`"${post.title}" 게시물을 삭제하시겠습니까?`)) return;

      posts = posts.filter(p => p.id !== id);
      this.save();
      window.authSystem.decrementPostCount(user.id);

      uiManager.refresh();
      uiUtils.showNotification('게시물이 삭제되었습니다.', 'info');
    },

    toggleLike(id) {
      const user = window.authSystem.getCurrentUser();
      if (!user) return uiUtils.showNotification('로그인이 필요합니다.', 'warning');

      const post = posts.find(p => p.id === id);
      if (!post) return;

      const likesKey = `dearme_likes_${user.id}`;
      let liked = safeJSON(localStorage.getItem(likesKey), []);

      if (liked.includes(id)) {
        liked = liked.filter(v => v !== id);
        post.likes = Math.max(0, post.likes - 1);
      } else {
        liked.push(id);
        post.likes++;
      }

      localStorage.setItem(likesKey, JSON.stringify(liked));
      this.save();
      uiManager.renderPosts();
    },

    userLiked(id) {
      const user = window.authSystem.getCurrentUser();
      if (!user) return false;

      const likesKey = `dearme_likes_${user.id}`;
      const liked = safeJSON(localStorage.getItem(likesKey), []);
      return liked.includes(id);
    },

    canView(post) {
      const user = window.authSystem.getCurrentUser();
      return post.visibility === 'public'
        || (user && user.id === post.authorId);
    },

    getFiltered() {
      const filterMap = {
        recent: p => [...p].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)),
        popular: p => [...p].sort((a, b) => b.likes - a.likes),
        opening: p => p.filter(p => dateUtils.isFuture(p.openAt))
                       .sort((a, b) => new Date(a.openAt) - new Date(b.openAt)),
        opened:  p => p.filter(p => dateUtils.isPast(p.openAt))
                       .sort((a, b) => new Date(b.openAt) - new Date(a.openAt))
      };
      return (filterMap[currentFilter] || filterMap.recent)(posts);
    }
  };

  /* ============================================
   렌더러
  ============================================= */
  const mediaRenderer = {
    image(file) {
      return $el('img', {
        src: file.data,
        alt: file.name,
        style: {
          width: '100%', height: 'auto',
          maxHeight: '400px', objectFit: 'contain'
        }
      });
    },

    video(file) {
      return $el('video', {
        src: file.data,
        controls: true,
        style: {
          width: '100%', height: 'auto',
          maxHeight: '400px', borderRadius: '8px'
        }
      });
    },

    document(file) {
      return $el('div', {
        style: {
          padding: '20px', textAlign: 'center',
          minHeight: '180px', display: 'flex',
          flexDirection: 'column', gap: '8px',
          alignItems: 'center', justifyContent: 'center'
        }
      }, [
        $el('div', { textContent: getFileIcon(file.type), style: { fontSize: '48px' } }),
        $el('div', { textContent: file.name, style: { fontSize: '12px', color: 'var(--text-secondary)' } }),
        $el('button', {
          className: 'btn ghost',
          textContent: '다운로드',
          onclick: () => downloadFile(file.data, file.name),
          style: { padding: '6px 12px', marginTop: '8px' }
        })
      ]);
    },

    renderMedia(files, isOpen) {
      if (!isOpen || !files?.length) return null;

      const grid = $el('div', {
        className: 'media-grid',
        style: { display: 'grid', gridTemplateColumns: '1fr', gap: '12px', marginTop: '16px' }
      });

      files.forEach(file => {
        const wrapper = $el('div', {
          className: 'media-item',
          style: { borderRadius: '8px', overflow: 'hidden', background: 'rgba(255,255,255,0.05)' }
        });

        const el = file.type.startsWith('image')
          ? this.image(file)
          : file.type.startsWith('video')
          ? this.video(file)
          : this.document(file);

        wrapper.appendChild(el);
        grid.appendChild(wrapper);
      });

      return grid;
    }
  };

  const uiManager = {
    renderPosts() {
      const list = els.postsList;
      if (!list) return;

      const data = postsManager.getFiltered();
      list.innerHTML = '';

      if (!data.length) return this.emptyState();

      const frag = document.createDocumentFragment();

      data.forEach(post => {
        if (postsManager.canView(post))
          frag.appendChild(this.createPost(post));
      });

      list.appendChild(frag);
    },

    createPost(post) {
      const isOpen = dateUtils.isPast(post.openAt);
      const liked = postsManager.userLiked(post.id);
      const user = window.authSystem.getCurrentUser();
      const isAuthor = user && user.id === post.authorId;

      const header = $el('div', { className: 'post-header' });
      header.innerHTML = `
        <div class="user-avatar">${post.authorAvatar}</div>
        <div class="post-author-info">
          <div class="post-author">${post.authorName}</div>
          <div class="post-meta">
            ${dateUtils.getRelativeTime(post.createdAt)}
            ${post.visibility === 'private' ? '<span style="margin-left:8px;color:var(--accent-primary)">🔒 비공개</span>' : ''}
          </div>
        </div>
        ${isAuthor ? '<div class="post-actions-header"><button class="btn ghost">🗑️ 삭제</button></div>' : ''}
      `;

      if (isAuthor) {
        header.querySelector('button').onclick = () =>
          postsManager.delete(post.id);
      }

      const body = $el('div', { className: 'post-body' }, [
        $el('h3', { className: 'post-title', textContent: post.title }),
        $el('div', { className: 'post-content', textContent: post.content || '(내용 없음)' })
      ]);

      const media = mediaRenderer.renderMedia(post.media, isOpen);
      if (media) body.appendChild(media);

      body.appendChild(
        $el('div', {
          className: 'post-open-date',
          innerHTML: `
            ${isOpen ? '🔓 개봉됨' : '🔒 개봉 예정'}: ${dateUtils.format(post.openAt, 'full')}
            <span style="margin-left:8px;opacity:.8;">(${dateUtils.getRelativeTime(post.openAt)})</span>
          `
        })
      );

      const footer = $el('div', { className: 'post-footer' });
      footer.appendChild($el('button', {
        className: `post-action-btn ${liked ? 'active' : ''}`,
        innerHTML: `${liked ? '❤️' : '🤍'} ${post.likes}`,
        onclick: () => postsManager.toggleLike(post.id)
      }));
      footer.appendChild($el('button', {
        className: 'post-action-btn',
        innerHTML: '🔗 공유',
        onclick: () => sharePost(post.id)
      }));

      return $el('article', { className: 'post-card' }, [header, body, footer]);
    },

    emptyState() {
      els.postsList.innerHTML = `
        <div class="empty-state" style="padding:80px 20px;">
          <div class="empty-state-icon">🔭</div>
          <div class="empty-state-title">아직 공유된 타임캡슐이 없습니다</div>
          <div class="empty-state-desc">첫 번째로 공유해보세요!</div>
          <a href="./timecapsule.html" class="btn primary" style="margin-top:20px;">타임캡슐 만들기</a>
        </div>
      `;
    },

    updateStats() {
      const totalPosts = posts.length;
      const totalUsers = window.authSystem.getAllUsers().length;
      const openedPosts = posts.filter(p => dateUtils.isPast(p.openAt)).length;

      const s = {
        posts: document.getElementById('statTotalPosts'),
        users: document.getElementById('statTotalUsers'),
        opened: document.getElementById('statOpenedPosts')
      };

      if (s.posts) s.posts.textContent = totalPosts;
      if (s.users) s.users.textContent = totalUsers;
      if (s.opened) s.opened.textContent = openedPosts;

      this.updateTrending();
    },

    updateTrending() {
      const container = document.getElementById('trendingUsers');
      if (!container) return;

      const users = window.authSystem.getAllUsers()
        .sort((a,b)=> (b.postCount||0)-(a.postCount||0))
        .slice(0,5);

      container.innerHTML = users.map(u => `
        <div class="trending-user">
          <div class="user-avatar" style="width:32px;height:32px;font-size:14px;">${u.avatar}</div>
          <div class="trending-user-name">${u.username}</div>
          <div class="trending-user-count">${u.postCount || 0}개</div>
        </div>
      `).join('');
    },

    renderUserInfo() {
      if (!els.userInfo) return;

      const user = window.authSystem.getCurrentUser();

      if (user) {
        els.userInfo.innerHTML = `
          <div class="user-info">
            <div class="user-avatar" style="width:32px;height:32px;font-size:14px;">${user.avatar}</div>
            <div class="user-name">${user.username}</div>
            <button class="btn ghost logout-btn" onclick="handleLogout()">로그아웃</button>
          </div>
        `;
      } else {
        els.userInfo.innerHTML = `
          <button class="btn primary" onclick="window.showLoginModal()">로그인</button>
          <button class="btn ghost" onclick="window.showRegisterModal()">회원가입</button>
        `;
      }
    },

    refresh() {
      this.renderPosts();
      this.updateStats();
    }
  };

  /* ============================================
   Utils exposed to global
  ============================================= */
  window.createCommunityPost = post => postsManager.create(post);
  window.deletePostById = id => postsManager.delete(id);
  window.likePost = id => postsManager.toggleLike(id);
  window.sharePost = id => sharePost(id);
  window.handleLogout = () => {
    if (confirm('로그아웃 하시겠습니까?')) {
      window.authSystem.logout();
      uiUtils.showNotification('로그아웃 되었습니다.', 'info');
      setTimeout(() => location.reload(), 500);
    }
  };
  window.downloadFile = (data, name) => {
    const a = document.createElement('a');
    a.href = data;
    a.download = name;
    a.click();
  };

  /* ============================================
   초기화
  ============================================= */
  function init() {
    postsManager.load();
    uiManager.refresh();
    uiManager.renderUserInfo();

    els.filterTabs.forEach(tab =>
      tab.addEventListener('click', () => {
        currentFilter = tab.dataset.filter;
        els.filterTabs.forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        uiManager.renderPosts();
      })
    );

    if (els.postTrigger) {
      els.postTrigger.onclick = () => {
        uiUtils.showNotification('타임캡슐 페이지에서 공개로 설정하면 공유됩니다!', 'info');
        setTimeout(() => location.href = './timecapsule.html', 1000);
      };
    }
  }

  document.readyState === 'loading'
    ? document.addEventListener('DOMContentLoaded', init)
    : init();

})();
