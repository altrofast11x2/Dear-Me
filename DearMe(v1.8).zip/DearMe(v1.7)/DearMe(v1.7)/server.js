const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'dearme_secret_key_2024';

app.use(cors());
app.use(express.json({ limit: '100mb' }));
app.use(express.static(path.join(__dirname, 'public')));

mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/dearme', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
})
    .then(() => console.log(' MongoDB 연결 성공'))
    .catch(err => console.error(' MongoDB 연결 실패:', err));

// User Schema
const userSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true },
    password: { type: String, required: true },
    avatar: { type: String, default: '' },
    createdAt: { type: Date, default: Date.now }
});

const User = mongoose.model('User', userSchema);

// Capsule Schema
const capsuleSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    title: { type: String, required: true },
    content: { type: String, default: '' },
    openAt: { type: Date, required: true },
    password: { type: String, default: '' },
    media: { name: String, type: String, data: String },
    isPublic: { type: Boolean, default: false },
    opened: { type: Boolean, default: false },
    openedAt: { type: Date },
    likes: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now }
});

const Capsule = mongoose.model('Capsule', capsuleSchema);

// Auth Middleware
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({ error: '로그인이 필요합니다.' });
    }

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) {
            return res.status(403).json({ error: '유효하지 않은 토큰입니다.' });
        }
        req.user = user;
        next();
    });
};

// Auth Routes
app.post('/api/auth/register', async (req, res) => {
    try {
        const { username, email, password } = req.body;

        if (!username || !email || !password) {
            return res.status(400).json({ error: '모든 필드를 입력해주세요.' });
        }

        if (password.length < 6) {
            return res.status(400).json({ error: '비밀번호는 6자 이상이어야 합니다.' });
        }

        const existingUser = await User.findOne({ $or: [{ username }, { email }] });
        if (existingUser) {
            return res.status(400).json({
                error: existingUser.username === username ? '이미 사용 중인 닉네임입니다.' : '이미 사용 중인 이메일입니다.'
            });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const user = new User({
            username,
            email,
            password: hashedPassword,
            avatar: username.charAt(0).toUpperCase()
        });

        await user.save();

        const token = jwt.sign({ userId: user._id, username: user.username }, JWT_SECRET, { expiresIn: '30d' });

        res.status(201).json({
            message: '회원가입이 완료되었습니다.',
            token,
            user: {
                id: user._id,
                username: user.username,
                email: user.email,
                avatar: user.avatar
            }
        });
    } catch (error) {
        console.error('회원가입 오류:', error);
        res.status(500).json({ error: '서버 오류가 발생했습니다.' });
    }
});

app.post('/api/auth/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        const user = await User.findOne({ email });
        if (!user) {
            return res.status(401).json({ error: '이메일 또는 비밀번호가 일치하지 않습니다.' });
        }

        const isValid = await bcrypt.compare(password, user.password);
        if (!isValid) {
            return res.status(401).json({ error: '이메일 또는 비밀번호가 일치하지 않습니다.' });
        }

        const token = jwt.sign({ userId: user._id, username: user.username }, JWT_SECRET, { expiresIn: '30d' });

        res.json({
            message: '로그인 되었습니다.',
            token,
            user: {
                id: user._id,
                username: user.username,
                email: user.email,
                avatar: user.avatar
            }
        });
    } catch (error) {
        console.error('로그인 오류:', error);
        res.status(500).json({ error: '서버 오류가 발생했습니다.' });
    }
});

app.get('/api/auth/me', authenticateToken, async (req, res) => {
    try {
        const user = await User.findById(req.user.userId).select('-password');
        res.json({ user });
    } catch (error) {
        res.status(500).json({ error: '서버 오류가 발생했습니다.' });
    }
});

// Capsule Routes
app.post('/api/capsules', authenticateToken, async (req, res) => {
    try {
        const { title, content, openAt, password, media, isPublic } = req.body;

        if (!title || !openAt) {
            return res.status(400).json({ error: '제목과 개봉 날짜는 필수입니다.' });
        }

        const capsule = new Capsule({
            userId: req.user.userId,
            title,
            content,
            openAt: new Date(openAt),
            password,
            media,
            isPublic: isPublic || false
        });

        await capsule.save();

        const populatedCapsule = await Capsule.findById(capsule._id)
            .populate('userId', 'username avatar');

        res.status(201).json({
            message: '타임캡슐이 생성되었습니다.',
            capsule: populatedCapsule
        });
    } catch (error) {
        console.error('캡슐 생성 오류:', error);
        res.status(500).json({ error: '서버 오류가 발생했습니다.' });
    }
});

app.get('/api/capsules/my', authenticateToken, async (req, res) => {
    try {
        const { filter, search } = req.query;

        let query = { userId: req.user.userId };

        if (search) {
            query.$or = [
                { title: { $regex: search, $options: 'i' } },
                { content: { $regex: search, $options: 'i' } }
            ];
        }

        if (filter === 'locked') {
            query.openAt = { $gt: new Date() };
        } else if (filter === 'open') {
            query.openAt = { $lte: new Date() };
        }

        const capsules = await Capsule.find(query)
            .populate('userId', 'username avatar')
            .sort({ createdAt: -1 });

        res.json({ capsules });
    } catch (error) {
        console.error('캡슐 조회 오류:', error);
        res.status(500).json({ error: '서버 오류가 발생했습니다.' });
    }
});

app.get('/api/capsules/:id', authenticateToken, async (req, res) => {
    try {
        const capsule = await Capsule.findById(req.params.id)
            .populate('userId', 'username avatar');

        if (!capsule) {
            return res.status(404).json({ error: '캡슐을 찾을 수 없습니다.' });
        }

        if (capsule.userId._id.toString() !== req.user.userId && !capsule.isPublic) {
            return res.status(403).json({ error: '접근 권한이 없습니다.' });
        }

        res.json({ capsule });
    } catch (error) {
        res.status(500).json({ error: '서버 오류가 발생했습니다.' });
    }
});

app.put('/api/capsules/:id', authenticateToken, async (req, res) => {
    try {
        const capsule = await Capsule.findOne({
            _id: req.params.id,
            userId: req.user.userId
        });

        if (!capsule) {
            return res.status(404).json({ error: '캡슐을 찾을 수 없습니다.' });
        }

        const { title, content, openAt, password, media, isPublic } = req.body;

        if (title) capsule.title = title;
        if (content !== undefined) capsule.content = content;
        if (openAt) capsule.openAt = new Date(openAt);
        if (password !== undefined) capsule.password = password;
        if (media !== undefined) capsule.media = media;
        if (isPublic !== undefined) capsule.isPublic = isPublic;

        capsule.updatedAt = new Date();

        await capsule.save();

        const updatedCapsule = await Capsule.findById(capsule._id)
            .populate('userId', 'username avatar');

        res.json({
            message: '캡슐이 수정되었습니다.',
            capsule: updatedCapsule
        });
    } catch (error) {
        console.error('캡슐 수정 오류:', error);
        res.status(500).json({ error: '서버 오류가 발생했습니다.' });
    }
});

app.delete('/api/capsules/:id', authenticateToken, async (req, res) => {
    try {
        const { password } = req.body;

        const capsule = await Capsule.findOne({
            _id: req.params.id,
            userId: req.user.userId
        });

        if (!capsule) {
            return res.status(404).json({ error: '캡슐을 찾을 수 없습니다.' });
        }

        if (capsule.password && capsule.password !== password) {
            return res.status(403).json({ error: '비밀번호가 일치하지 않습니다.' });
        }

        await Capsule.findByIdAndDelete(req.params.id);

        res.json({ message: '캡슐이 삭제되었습니다.' });
    } catch (error) {
        console.error('캡슐 삭제 오류:', error);
        res.status(500).json({ error: '서버 오류가 발생했습니다.' });
    }
});

app.put('/api/capsules/:id/open', authenticateToken, async (req, res) => {
    try {
        const capsule = await Capsule.findById(req.params.id);

        if (!capsule) {
            return res.status(404).json({ error: '캡슐을 찾을 수 없습니다.' });
        }

        if (capsule.userId.toString() !== req.user.userId && !capsule.isPublic) {
            return res.status(403).json({ error: '접근 권한이 없습니다.' });
        }

        if (!capsule.opened) {
            capsule.opened = true;
            capsule.openedAt = new Date();
            await capsule.save();
        }

        res.json({ message: '캡슐이 열렸습니다.' });
    } catch (error) {
        res.status(500).json({ error: '서버 오류가 발생했습니다.' });
    }
});

// Community Routes
app.get('/api/community/capsules', async (req, res) => {
    try {
        const { filter, page = 1, limit = 20 } = req.query;

        let query = { isPublic: true };
        let sort = { createdAt: -1 };

        if (filter === 'popular') {
            sort = { likes: -1, createdAt: -1 };
        } else if (filter === 'opening') {
            query.openAt = { $gt: new Date() };
            sort = { openAt: 1 };
        } else if (filter === 'opened') {
            query.openAt = { $lte: new Date() };
            sort = { openAt: -1 };
        }

        const skip = (parseInt(page) - 1) * parseInt(limit);

        const capsules = await Capsule.find(query)
            .populate('userId', 'username avatar')
            .sort(sort)
            .skip(skip)
            .limit(parseInt(limit));

        const total = await Capsule.countDocuments(query);

        const capsulesWithCounts = capsules.map(capsule => ({
            ...capsule.toObject(),
            likesCount: capsule.likes ? capsule.likes.length : 0
        }));

        res.json({
            capsules: capsulesWithCounts,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total,
                pages: Math.ceil(total / parseInt(limit))
            }
        });
    } catch (error) {
        console.error('커뮤니티 조회 오류:', error);
        res.status(500).json({ error: '서버 오류가 발생했습니다.' });
    }
});

app.post('/api/capsules/:id/like', authenticateToken, async (req, res) => {
    try {
        const capsule = await Capsule.findById(req.params.id);

        if (!capsule) {
            return res.status(404).json({ error: '캡슐을 찾을 수 없습니다.' });
        }

        if (!capsule.isPublic) {
            return res.status(403).json({ error: '공개된 캡슐만 좋아요할 수 있습니다.' });
        }

        const likeIndex = capsule.likes.indexOf(req.user.userId);

        if (likeIndex > -1) {
            capsule.likes.splice(likeIndex, 1);
        } else {
            capsule.likes.push(req.user.userId);
        }

        await capsule.save();

        res.json({
            message: likeIndex > -1 ? '좋아요가 취소되었습니다.' : '좋아요를 눌렀습니다.',
            likesCount: capsule.likes.length,
            isLiked: likeIndex === -1
        });
    } catch (error) {
        console.error('좋아요 오류:', error);
        res.status(500).json({ error: '서버 오류가 발생했습니다.' });
    }
});

// Statistics Routes
app.get('/api/stats', async (req, res) => {
    try {
        const totalCapsules = await Capsule.countDocuments({ isPublic: true });
        const totalUsers = await User.countDocuments();
        const openedCapsules = await Capsule.countDocuments({
            isPublic: true,
            openAt: { $lte: new Date() }
        });

        const topUsers = await Capsule.aggregate([
            { $match: { isPublic: true } },
            { $group: { _id: '$userId', count: { $sum: 1 } } },
            { $sort: { count: -1 } },
            { $limit: 5 },
            {
                $lookup: {
                    from: 'users',
                    localField: '_id',
                    foreignField: '_id',
                    as: 'user'
                }
            },
            { $unwind: '$user' },
            {
                $project: {
                    username: '$user.username',
                    avatar: '$user.avatar',
                    capsuleCount: '$count'
                }
            }
        ]);

        res.json({
            totalCapsules,
            totalUsers,
            openedCapsules,
            topUsers
        });
    } catch (error) {
        console.error('통계 조회 오류:', error);
        res.status(500).json({ error: '서버 오류가 발생했습니다.' });
    }
});

app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'main.html'));
});

app.listen(PORT, () => {
    console.log(`서버가 포트 ${PORT}에서 실행 중입니다.`);
    console.log(`http://localhost:${PORT}`);
});