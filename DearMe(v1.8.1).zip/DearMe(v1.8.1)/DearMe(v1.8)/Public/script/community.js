/* ============================================
   Dear Me - 커뮤니티 시스템 (다중 파일 지원)
   ============================================ */

(function () {
  'use strict';

  const POSTS_KEY = 'dearme_community_posts_v1';

  let posts = [];
  let currentFilter = 'recent';

  const elements = {
    postsList: document.getElementById('postsList'),
    filterTabs: document.querySelectorAll('.filter-tab'),
    postTrigger: document.getElementById('postTrigger'),
    userInfo: document.getElementById('userInfo')
  };

  /* ============================================
     파일 아이콘
     ============================================ */
  function getFileIcon(fileType) {
    if (fileType.startsWith('image/')) return '🖼️';
    if (fileType.startsWith('video/')) return '🎥';
    if (fileType.includes('pdf')) return '📄';
    if (fileType.includes('word') || fileType.includes('document')) return '📝';
    if (fileType.includes('sheet') || fileType.includes('excel')) return '📊';
    if (fileType.includes('text')) return '📃';
    return '📎';
  }

  /* ============================================
     포스트 관리
     ============================================ */
  function loadPosts() {
    try {
      const data = localStorage.getItem(POSTS_KEY);
      posts = data ? JSON.parse(data) : [];
      posts = posts.filter(post => post.id && post.authorId && post.title);
    } catch (error) {
      console.error('포스트 로드 실패:', error);
      posts = [];
    }
  }

  function savePosts() {
    try {
      localStorage.setItem(POSTS_KEY, JSON.stringify(posts));
      return true;
    } catch (error) {
      console.error('포스트 저장 실패:', error);
      return false;
    }
  }

  function createPost(postData) {
    const currentUser = window.authSystem.getCurrentUser();

    if (!currentUser) {
      uiUtils.showNotification('로그인이 필요합니다.', 'warning');
      window.showLoginModal();
      return false;
    }

    // 미디어 배열 안전하게 복사
    let mediaCopy = [];
    if (postData.media && Array.isArray(postData.media)) {
      try {
        mediaCopy = JSON.parse(JSON.stringify(postData.media));
      } catch (e) {
        console.error('미디어 복사 오류:', e);
        mediaCopy = [];
      }
    }

    const newPost = {
      id: securityUtils.generateSecureId(),
      authorId: currentUser.id,
      authorName: currentUser.username,
      authorAvatar: currentUser.avatar,
      title: securityUtils.sanitizeInput(postData.title, 200),
      content: securityUtils.sanitizeInput(postData.content, 10000),
      openAt: postData.openAt,
      password: postData.password || '',
      media: mediaCopy,
      visibility: postData.visibility || 'public',
      createdAt: new Date().toISOString(),
      likes: 0,
      comments: 0,
      originalCapsuleId: postData.originalCapsuleId || null
    };

    posts.unshift(newPost);

    const saved = savePosts();
    if (!saved) {
      uiUtils.showNotification('게시물 저장에 실패했습니다.', 'error');
      return false;
    }

    window.authSystem.incrementPostCount(currentUser.id);

    renderPosts();
    updateStats();

    uiUtils.showNotification('타임캡슐이 커뮤니티에 공유되었습니다!', 'success');
    return true;
  }

  function deletePost(postId) {
    const post = posts.find(p => p.id === postId);
    if (!post) return;

    const currentUser = window.authSystem.getCurrentUser();

    if (!currentUser || post.authorId !== currentUser.id) {
      uiUtils.showNotification('본인의 게시물만 삭제할 수 있습니다.', 'error');
      return;
    }

    if (post.password) {
      const inputPassword = prompt('게시물 비밀번호를 입력하세요:');
      if (inputPassword === null) return;
      if (inputPassword !== post.password) {
        uiUtils.showNotification('비밀번호가 일치하지 않습니다.', 'error');
        return;
      }
    }

    const confirmMessage = `"${post.title}" 게시물을 삭제하시겠습니까?`;
    if (!confirm(confirmMessage)) return;

    if (post.originalCapsuleId && window.resetCapsuleShareStatus) {
      window.resetCapsuleShareStatus(post.originalCapsuleId);
    }

    posts = posts.filter(p => p.id !== postId);
    savePosts();

    window.authSystem.decrementPostCount(currentUser.id);

    renderPosts();
    updateStats();

    uiUtils.showNotification('게시물이 삭제되었습니다.', 'info');
  }

  function toggleLike(postId) {
    const currentUser = window.authSystem.getCurrentUser();

    if (!currentUser) {
      uiUtils.showNotification('로그인이 필요합니다.', 'warning');
      window.showLoginModal();
      return;
    }

    const post = posts.find(p => p.id === postId);
    if (!post) return;

    if (post.visibility === 'private' && post.authorId !== currentUser.id) {
      uiUtils.showNotification('비공개 게시물입니다.', 'warning');
      return;
    }

    const likesKey = `dearme_likes_${currentUser.id}`;
    let userLikes = JSON.parse(localStorage.getItem(likesKey) || '[]');

    if (userLikes.includes(postId)) {
      userLikes = userLikes.filter(id => id !== postId);
      post.likes = Math.max(0, post.likes - 1);
    } else {
      userLikes.push(postId);
      post.likes++;
    }

    localStorage.setItem(likesKey, JSON.stringify(userLikes));
    savePosts();
    renderPosts();
  }

  function hasUserLiked(postId) {
    const currentUser = window.authSystem.getCurrentUser();
    if (!currentUser) return false;

    const likesKey = `dearme_likes_${currentUser.id}`;
    const userLikes = JSON.parse(localStorage.getItem(likesKey) || '[]');
    return userLikes.includes(postId);
  }

  function canViewPost(post) {
    const currentUser = window.authSystem.getCurrentUser();
    if (post.visibility === 'public') return true;
    if (post.visibility === 'private') {
      return currentUser && currentUser.id === post.authorId;
    }
    return false;
  }

  /* ============================================
     렌더링
     ============================================ */
  function renderPosts() {
    if (!elements.postsList) return;

    const filtered = getFilteredPosts();
    elements.postsList.innerHTML = '';

    if (filtered.length === 0) {
      renderEmptyState();
      return;
    }

    filtered.forEach(post => {
      if (canViewPost(post)) {
        const postElement = createPostElement(post);
        elements.postsList.appendChild(postElement);
      }
    });
  }

  function getFilteredPosts() {
    let filtered = [...posts];

    switch (currentFilter) {
      case 'recent':
        filtered.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        break;
      case 'popular':
        filtered.sort((a, b) => b.likes - a.likes);
        break;
      case 'opening':
        filtered = filtered.filter(p => dateUtils.isFuture(p.openAt));
        filtered.sort((a, b) => new Date(a.openAt) - new Date(b.openAt));
        break;
      case 'opened':
        filtered = filtered.filter(p => dateUtils.isPast(p.openAt));
        filtered.sort((a, b) => new Date(b.openAt) - new Date(a.openAt));
        break;
    }

    return filtered;
  }

  function createPostElement(post) {
    const isOpen = dateUtils.isPast(post.openAt);
    const isLiked = hasUserLiked(post.id);
    const currentUser = window.authSystem.getCurrentUser();
    const isAuthor = currentUser && currentUser.id === post.authorId;

    // 미디어 배열 처리
    const hasMedia = post.media && Array.isArray(post.media) && post.media.length > 0;
    const showMedia = isOpen && hasMedia;

    const article = document.createElement('article');
    article.className = 'post-card';

    // 헤더 생성
    const headerDiv = document.createElement('div');
    headerDiv.className = 'post-header';
    headerDiv.innerHTML = `
              <div class="user-avatar">${post.authorAvatar}</div>
              <div class="post-author-info">
                  <div class="post-author">${post.authorName}</div>
                  <div class="post-meta">
                      ${dateUtils.getRelativeTime(post.createdAt)}
                      ${post.visibility === 'private' ? '<span style="margin-left: 8px; color: var(--accent-primary);">🔒 비공개</span>' : ''}
                  </div>
              </div>
              ${isAuthor ? `
                  <div class="post-actions-header">
                      <button class="btn ghost" style="padding: 6px 12px; font-size: 13px;">
                          🗑️ 삭제
                      </button>
                  </div>
              ` : ''}
          `;

    // 바디 생성
    const bodyDiv = document.createElement('div');
    bodyDiv.className = 'post-body';

    const titleEl = document.createElement('h3');
    titleEl.className = 'post-title';
    titleEl.textContent = post.title;

    const contentEl = document.createElement('div');
    contentEl.className = 'post-content';
    contentEl.textContent = post.content || '(내용 없음)';

    bodyDiv.appendChild(titleEl);
    bodyDiv.appendChild(contentEl);

    // 미디어 처리
    if (showMedia) {
      const mediaGrid = document.createElement('div');
      mediaGrid.className = 'media-grid';

      // 한 줄에 하나씩 꽉 차게
      mediaGrid.style.cssText =
        'display: grid; grid-template-columns: 1fr; gap: 12px; margin-top: 16px;';

      post.media.forEach(file => {
        const mediaItem = document.createElement('div');
        mediaItem.className = 'media-item';
        mediaItem.style.cssText =
          'border-radius: 8px; overflow: hidden; background: rgba(255,255,255,0.05);';

        /* ============================================
           이미지 처리 (100% 꽉 차게 + 비율 유지)
        ============================================= */
        if (file.type.startsWith('image')) {
          const img = document.createElement('img');
          img.src = file.data;
          img.alt = file.name;
          img.loading = 'lazy';

          img.style.cssText = `
          width: 100%;
          height: auto;
          max-height: 400px;
          object-fit: contain;
        `;

          mediaItem.appendChild(img);
        }

        /* ============================================
           영상 처리 (100% 꽉 차게 + 비율 유지 + 너무 크면 제한)
        ============================================= */
        else if (file.type.startsWith('video')) {
          const video = document.createElement('video');
          video.src = file.data;
          video.controls = true;

          video.style.cssText = `
          width: 100%;
          max-width: 100%;
          height: auto;
          max-height: 400px;
          border-radius: 8px;
        `;

          mediaItem.appendChild(video);
        }

        /* ============================================
           문서 처리
        ============================================= */
        else {
          const docDiv = document.createElement('div');
          docDiv.style.cssText = `
          padding: 20px;
          text-align: center;
          min-height: 180px;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          gap: 8px;
        `;

          const iconDiv = document.createElement('div');
          iconDiv.style.fontSize = '48px';
          iconDiv.textContent = getFileIcon(file.type);

          const nameDiv = document.createElement('div');
          nameDiv.style.cssText =
            'font-size: 12px; color: var(--text-secondary); word-break: break-word;';
          nameDiv.textContent = file.name;

          const downloadBtn = document.createElement('button');
          downloadBtn.className = 'btn ghost';
          downloadBtn.style.cssText = 'margin-top: 8px; padding: 6px 12px; font-size: 12px;';
          downloadBtn.textContent = '다운로드';
          downloadBtn.onclick = () => downloadFile(file.data, file.name);

          docDiv.appendChild(iconDiv);
          docDiv.appendChild(nameDiv);
          docDiv.appendChild(downloadBtn);
          mediaItem.appendChild(docDiv);
        }

        mediaGrid.appendChild(mediaItem);
      });

      bodyDiv.appendChild(mediaGrid);
    }

    // 개봉 날짜
    const openDateDiv = document.createElement('div');
    openDateDiv.className = 'post-open-date';
    openDateDiv.innerHTML = `
              ${isOpen ? '🔓' : '🔒'} 
              ${isOpen ? '개봉됨' : '개봉 예정'}: ${dateUtils.format(post.openAt, 'full')}
              <span style="margin-left: 8px; opacity: 0.8;">(${dateUtils.getRelativeTime(post.openAt)})</span>
          `;
    bodyDiv.appendChild(openDateDiv);

    // 푸터 생성
    const footerDiv = document.createElement('div');
    footerDiv.className = 'post-footer';

    const likeBtn = document.createElement('button');
    likeBtn.className = `post-action-btn ${isLiked ? 'active' : ''}`;
    likeBtn.innerHTML = `${isLiked ? '❤️' : '🤍'} ${post.likes || 0}`;
    likeBtn.onclick = () => toggleLike(post.id);

    const shareBtn = document.createElement('button');
    shareBtn.className = 'post-action-btn';
    shareBtn.innerHTML = '🔗 공유';
    shareBtn.onclick = () => sharePost(post.id);

    footerDiv.appendChild(likeBtn);
    footerDiv.appendChild(shareBtn);

    // 조립
    article.appendChild(headerDiv);
    article.appendChild(bodyDiv);
    article.appendChild(footerDiv);

    // 삭제 버튼 이벤트
    if (isAuthor) {
      const deleteBtn = headerDiv.querySelector('.post-actions-header button');
      if (deleteBtn) {
        deleteBtn.onclick = () => deletePost(post.id);
      }
    }

    return article;
  }

  function renderEmptyState() {
    elements.postsList.innerHTML = `
        <div class="empty-state" style="padding: 80px 20px;">
          <div class="empty-state-icon">🔭</div>
          <div class="empty-state-title">아직 공유된 타임캡슐이 없습니다</div>
          <div class="empty-state-desc">
            첫 번째로 타임캡슐을 만들어 커뮤니티에 공유해보세요!
          </div>
          <a href="./timecapsule.html" class="btn primary" style="margin-top: 20px; text-decoration: none;">
            타임캡슐 만들기
          </a>
        </div>
      `;
  }

  /* ============================================
     통계 업데이트
     ============================================ */
  function updateStats() {
    const totalPosts = posts.length;
    const totalUsers = window.authSystem.getAllUsers().length;
    const openedPosts = posts.filter(p => dateUtils.isPast(p.openAt)).length;

    const statsElements = {
      totalPosts: document.getElementById('statTotalPosts'),
      totalUsers: document.getElementById('statTotalUsers'),
      openedPosts: document.getElementById('statOpenedPosts')
    };

    if (statsElements.totalPosts) statsElements.totalPosts.textContent = totalPosts;
    if (statsElements.totalUsers) statsElements.totalUsers.textContent = totalUsers;
    if (statsElements.openedPosts) statsElements.openedPosts.textContent = openedPosts;

    updateTrendingUsers();
  }

  function updateTrendingUsers() {
    const trendingContainer = document.getElementById('trendingUsers');
    if (!trendingContainer) return;

    const users = window.authSystem.getAllUsers();
    const sorted = users
      .sort((a, b) => (b.postCount || 0) - (a.postCount || 0))
      .slice(0, 5);

    trendingContainer.innerHTML = sorted.map(user => `
        <div class="trending-user">
          <div class="user-avatar" style="width: 32px; height: 32px; font-size: 14px;">
            ${user.avatar}
          </div>
          <div class="trending-user-name">${user.username}</div>
          <div class="trending-user-count">${user.postCount || 0}개</div>
        </div>
      `).join('');
  }

  /* ============================================
     이벤트 핸들러
     ============================================ */
  function handleFilterChange(filter) {
    currentFilter = filter;

    elements.filterTabs.forEach(tab => {
      tab.classList.remove('active');
      if (tab.dataset.filter === filter) {
        tab.classList.add('active');
      }
    });

    renderPosts();
  }

  function sharePost(postId) {
    const url = `${window.location.origin}${window.location.pathname}?post=${postId}`;

    if (navigator.clipboard) {
      navigator.clipboard.writeText(url).then(() => {
        uiUtils.showNotification('링크가 클립보드에 복사되었습니다!', 'success');
      }).catch(() => {
        prompt('이 링크를 복사하세요:', url);
      });
    } else {
      prompt('이 링크를 복사하세요:', url);
    }
  }

  function downloadFile(base64Data, filename) {
    const link = document.createElement('a');
    link.href = base64Data;
    link.download = filename;
    link.click();
  }

  /* ============================================
     사용자 UI 렌더링
     ============================================ */
  function renderUserInfo() {
    if (!elements.userInfo) return;

    const currentUser = window.authSystem.getCurrentUser();

    if (currentUser) {
      elements.userInfo.innerHTML = `
          <div class="user-info">
            <div class="user-avatar" style="width: 32px; height: 32px; font-size: 14px;">
              ${currentUser.avatar}
            </div>
            <div class="user-name">${currentUser.username}</div>
            <button class="btn ghost logout-btn" onclick="handleLogout()">로그아웃</button>
          </div>
        `;
    } else {
      elements.userInfo.innerHTML = `
          <button class="btn primary" onclick="window.showLoginModal()">
            로그인
          </button>
          <button class="btn ghost" onclick="window.showRegisterModal()">
            회원가입
          </button>
        `;
    }
  }

  function handleLogout() {
    if (confirm('로그아웃 하시겠습니까?')) {
      window.authSystem.logout();
      uiUtils.showNotification('로그아웃 되었습니다.', 'info');
      setTimeout(() => {
        window.location.reload();
      }, 500);
    }
  }

  /* ============================================
     초기화
     ============================================ */
  function init() {
    loadPosts();
    renderPosts();
    renderUserInfo();
    updateStats();

    elements.filterTabs.forEach(tab => {
      tab.addEventListener('click', () => {
        handleFilterChange(tab.dataset.filter);
      });
    });

    if (elements.postTrigger) {
      elements.postTrigger.addEventListener('click', () => {
        uiUtils.showNotification('타임캡슐 페이지에서 공개로 설정하면 자동으로 공유됩니다!', 'info');
        setTimeout(() => {
          window.location.href = './timecapsule.html';
        }, 1000);
      });
    }
  }

  /* ============================================
     전역 함수
     ============================================ */
  window.createCommunityPost = createPost;
  window.deletePostById = deletePost;
  window.likePost = toggleLike;
  window.sharePost = sharePost;
  window.handleLogout = handleLogout;
  window.downloadFile = downloadFile;

  /* ============================================
     앱 시작
     ============================================ */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();